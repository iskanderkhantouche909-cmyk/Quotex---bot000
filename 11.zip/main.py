import os
import asyncio
import random
import time
from datetime import datetime, timedelta
from flask import Flask, request, render_template_string
from pyquotex.stable_api import Quotex
from telethon import TelegramClient

API_ID = 21508855
API_HASH = "290e3791a95daa5fffcd1847a1b5da17"
CHANNEL = "@latchidz1"

ASSETS = ["NZDCHF_otc", "USDINR_otc", "USDBDT_otc", "USDARS_otc", "USDPKR_otc"]
BASE_AMOUNT = 1.0

app = Flask(__name__)
bot_running = False

# واجهة HTML
login_page = """
<!DOCTYPE html>
<html>
<head>
    <title>Quotex Bot</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        h1 { margin-top: 20px; }
        .btn {
            display: inline-block;
            padding: 20px 40px;
            font-size: 24px;
            margin: 20px;
            border-radius: 10px;
            text-decoration: none;
            color: white;
            font-weight: bold;
        }
        .start { background-color: green; }
        .stop { background-color: red; }
    </style>
</head>
<body>
    <h1>Quotex Trading Bot</h1>
    <form method="POST" action="/login">
        <label>Email:</label><br>
        <input type="text" name="email"><br><br>
        <label>Password:</label><br>
        <input type="password" name="password"><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
"""

control_page = """
<!DOCTYPE html>
<html>
<head>
    <title>Quotex Bot Control</title>
</head>
<body style="text-align:center; font-family:Arial;">
    <h1>Welcome {{email}}</h1>
    <a href="/start?email={{email}}&password={{password}}" class="btn start">START TRADING</a>
    <a href="/stop" class="btn stop">STOP TRADING</a>
</body>
</html>
"""

async def decide_direction(client, asset):
    candles = await client.get_candles(asset, int(time.time()), 3, 60)
    if candles:
        ups = sum(1 for c in candles if c["close"] > c["open"])
        downs = sum(1 for c in candles if c["close"] < c["open"])
        return "call" if ups > downs else "put"
    return random.choice(["call","put"])

async def trade_loop(email, password):
    global bot_running
    client = Quotex(email=email, password=password, lang="en")
    client.set_account_mode("PRACTICE")
    connected, reason = await client.connect()
    if not connected:
        print("❌ فشل الاتصال:", reason)
        return
    await client.change_account("PRACTICE")

    tg = TelegramClient("session", API_ID, API_HASH)
    await tg.start()

    while bot_running:
        asset = random.choice(ASSETS)
        direction = await decide_direction(client, asset)
        next_minute = (datetime.now().replace(second=0, microsecond=0) + timedelta(minutes=2))
        entry_time = next_minute.strftime("%H:%M")

        preview_msg = f"{asset.upper()} | M1 | {entry_time} | {direction.upper()}"
        await tg.send_message(CHANNEL, preview_msg)

        await asyncio.sleep(120)  # انتظار قبل الصفقة الجديدة

@app.route("/")
def home():
    return login_page

@app.route("/login", methods=["POST"])
def login():
    email = request.form.get("email")
    password = request.form.get("password")
    return render_template_string(control_page, email=email, password=password)

@app.route("/start")
def start():
    global bot_running
    email = request.args.get("email")
    password = request.args.get("password")
    bot_running = True
    asyncio.create_task(trade_loop(email, password))
    return "✅ Trading started!"

@app.route("/stop")
def stop():
    global bot_running
    bot_running = False
    return "⛔ Trading stopped."

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)